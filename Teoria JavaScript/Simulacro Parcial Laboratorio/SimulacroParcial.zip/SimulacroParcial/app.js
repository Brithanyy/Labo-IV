/* Imports, inicializacion de la aplicacion y demas
Se espera que la logica este separada en distintos modulos
*/